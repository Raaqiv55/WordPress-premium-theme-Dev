<?php 
/*
Plugin Name:    firsttheme metaboxes
Plugin URI: 
Description:    Adding Metaboxes for firsttheme
Version:        1.0.0
Author:         Alamgir
Author:         alamgir.online
License:        GPL2
License URI:    someurl.com
Text Domain:    firsttheme-metaboxes
Domain Path:    /language
*/
if(!defined('WPINC')){
    die;
}

include_once('includes/metaboxes.php');
include_once('includes/enqueue-assets.php');