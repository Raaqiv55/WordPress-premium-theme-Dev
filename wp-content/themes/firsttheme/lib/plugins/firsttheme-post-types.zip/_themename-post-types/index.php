<?php 
/*
Plugin Name:    firsttheme post_types
Plugin URI: 
Description:    Adding Custom Post Types for firsttheme
Version:        1.0.0
Author:         Alamgir
Author:         alamgir.online
License:        GPL2
License URI:    someurl.com
Text Domain:    firsttheme-post_types
Domain Path:    /language
*/
if(!defined('WPINC')){
    die;
}

include_once('includes/porfolio-post-type.php');
include_once('includes/project-type-tax.php');
include_once('includes/skills-tax.php');